package jug.normandy.jsf.presentation.composants.managedBean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

import jug.normandy.jsf.presentation.composants.bean.LigneBean;

/**
 * Classe de présentation relative à la liste des composants
 * 
 * @author gTombette
 * @version $Revision$
 */
@ManagedBean(name = "composantsBean")
@RequestScoped
public class ComposantsBean implements Serializable {

    /**
     * Identifiant serialVersionUID pour la sérialisation
     */
    private static final long serialVersionUID = 6492805458074995507L;

    /**
     * Champ de type InputText
     */
    private String inputText;

    /**
     * Champ de type InputSecret
     */
    private String inputSecret;

    /**
     * Champ de type InputTextarea
     */
    private String inputTextarea;

    /**
     * Champ de type OutputText
     */
    private String outputText;

    /**
     * Champ de type dataTable
     */
    private List<LigneBean> dataTable;

    
    /**
     * Constructeur
     */
    public ComposantsBean() {
        super();
        this.outputText ="NormandyJug";
        this.dataTable = new ArrayList<LigneBean>();
        
        LigneBean ligne = new LigneBean();
        ligne.setColonne1("Cellule01");
        ligne.setColonne2("Cellule02");
        ligne.setColonne3("Cellule03");
        this.dataTable.add(ligne);

        ligne = new LigneBean();
        ligne.setColonne1("Cellule11");
        ligne.setColonne2("Cellule12");
        ligne.setColonne3("Cellule13");
        this.dataTable.add(ligne);

        ligne = new LigneBean();
        ligne.setColonne1("Cellule21");
        ligne.setColonne2("Cellule22");
        ligne.setColonne3("Cellule23");
        this.dataTable.add(ligne);

        ligne = new LigneBean();
        ligne.setColonne1("Cellule31");
        ligne.setColonne2("Cellule32");
        ligne.setColonne3("Cellule33");
        this.dataTable.add(ligne);
}

    /**
     * Accesseur pour l'attribut inputText
     * 
     * @return Retourne la valeur de l'attribut inputText.
     */
    public String getInputText() {
        return this.inputText;
    }

    /**
     * Mutateur de l'attribut inputText
     * 
     * @param _inputText Valeur associée à l'attribut inputText.
     */
    public void setInputText(String _inputText) {
        this.inputText = _inputText;
    }

    /**
     * Accesseur pour l'attribut inputSecret
     * 
     * @return Retourne la valeur de l'attribut inputSecret.
     */
    public String getInputSecret() {
        return this.inputSecret;
    }

    /**
     * Mutateur de l'attribut inputSecret
     * 
     * @param _inputSecret Valeur associée à l'attribut inputSecret.
     */
    public void setInputSecret(String _inputSecret) {
        this.inputSecret = _inputSecret;
    }

    /**
     * Accesseur pour l'attribut inputTextarea
     * 
     * @return Retourne la valeur de l'attribut inputTextarea.
     */
    public String getInputTextarea() {
        return this.inputTextarea;
    }

    /**
     * Mutateur de l'attribut inputTextarea
     * 
     * @param _inputTextarea Valeur associée à l'attribut inputTextarea.
     */
    public void setInputTextarea(String _inputTextarea) {
        this.inputTextarea = _inputTextarea;
    }

    /**
     * Accesseur pour l'attribut outputText
     * @return Retourne la valeur de l'attribut outputText.
     */
    public String getOutputText() {
        return this.outputText;
    }

    /**
     * Mutateur de l'attribut outputText
     * @param _outputText Valeur associée à l'attribut outputText.
     */
    public void setOutputText(String _outputText) {
        this.outputText = _outputText;
    }

    /**
     * Accesseur pour l'attribut dataTable
     * @return Retourne la valeur de l'attribut dataTable.
     */
    public List<LigneBean> getDataTable() {
        return this.dataTable;
    }

    /**
     * Mutateur de l'attribut dataTable
     * @param _dataTable Valeur associée à l'attribut dataTable.
     */
    public void setDataTable(List<LigneBean> _dataTable) {
        this.dataTable = _dataTable;
    }
}
