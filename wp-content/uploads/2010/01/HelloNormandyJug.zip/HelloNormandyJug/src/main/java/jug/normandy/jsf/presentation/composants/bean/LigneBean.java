package jug.normandy.jsf.presentation.composants.bean;

/** 
 * Classe représentant une ligne du tableau
 *
 * @author gTombette
 * @version $Revision$
 */
public class LigneBean {

    /**
     * Colonne 1
     */
    private String colonne1;
    
    /**
     * Colonne 2
     */
    private String colonne2;

    /**
     * Colonne 3
     */
    private String colonne3;

    
    /** 
     * Constructeur
     */
    public LigneBean() {
        super();
    }

    
    /**
     * Accesseur pour l'attribut colonne1
     * @return Retourne la valeur de l'attribut colonne1.
     */
    public String getColonne1() {
        return this.colonne1;
    }


    /**
     * Mutateur de l'attribut colonne1
     * @param _colonne1 Valeur associée à l'attribut colonne1.
     */
    public void setColonne1(String _colonne1) {
        this.colonne1 = _colonne1;
    }


    /**
     * Accesseur pour l'attribut colonne2
     * @return Retourne la valeur de l'attribut colonne2.
     */
    public String getColonne2() {
        return this.colonne2;
    }


    /**
     * Mutateur de l'attribut colonne2
     * @param _colonne2 Valeur associée à l'attribut colonne2.
     */
    public void setColonne2(String _colonne2) {
        this.colonne2 = _colonne2;
    }


    /**
     * Accesseur pour l'attribut colonne3
     * @return Retourne la valeur de l'attribut colonne3.
     */
    public String getColonne3() {
        return this.colonne3;
    }


    /**
     * Mutateur de l'attribut colonne3
     * @param _colonne3 Valeur associée à l'attribut colonne3.
     */
    public void setColonne3(String _colonne3) {
        this.colonne3 = _colonne3;
    }

}
