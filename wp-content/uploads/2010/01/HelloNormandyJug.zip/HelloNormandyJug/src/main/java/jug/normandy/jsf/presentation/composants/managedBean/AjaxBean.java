package jug.normandy.jsf.presentation.composants.managedBean;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

/**
 * Classe de présentation relative à l'essai d'AJAX
 * 
 * @author gTombette
 * @version $Revision$
 */
@ManagedBean(name = "ajaxBean")
@RequestScoped
public class AjaxBean implements Serializable {

    /**
     * Identifiant serialVersionUID pour la sérialisation
     */
    private static final long serialVersionUID = -1004212364664239025L;

    /**
     * Nom de l'utilisateur
     */
    private String nom;

    /**
     * Prénom de l'utilisateur
     */
    private String prenom;

    /**
     * Âge de l'utilisateur
     */
    private int age;

    /**
     * Constructeur
     */
    public AjaxBean() {
        super();
    }

    /**
     * Accesseur pour l'attribut nom
     * 
     * @return Retourne la valeur de l'attribut nom.
     */
    public String getNom() {
        return this.nom;
    }

    /**
     * Mutateur de l'attribut nom
     * 
     * @param _nom Valeur associée à l'attribut nom.
     */
    public void setNom(String _nom) {
        this.nom = _nom;
    }

    /**
     * Accesseur pour l'attribut prenom
     * 
     * @return Retourne la valeur de l'attribut prenom.
     */
    public String getPrenom() {
        return this.prenom;
    }

    /**
     * Mutateur de l'attribut prenom
     * 
     * @param _prenom Valeur associée à l'attribut prenom.
     */
    public void setPrenom(String _prenom) {
        this.prenom = _prenom;
    }

    /**
     * Accesseur pour l'attribut age
     * 
     * @return Retourne la valeur de l'attribut age.
     */
    public int getAge() {
        return this.age;
    }

    /**
     * Mutateur de l'attribut age
     * 
     * @param _age Valeur associée à l'attribut age.
     */
    public void setAge(int _age) {
        this.age = _age;
    }

}
