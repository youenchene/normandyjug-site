package jug.normandy.jsf.presentation.composants.managedBean;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

/**
 * Classe de présentation relative à la création de composant
 * 
 * @author gTombette
 * @version $Revision$
 */
@ManagedBean(name = "monComposantsBean")
@RequestScoped
public class MonComposantsBean implements Serializable {

    /**
     * Identifiant serialVersionUID pour la sérialisation
     */
    private static final long serialVersionUID = -4955732711210149764L;

    /**
     * Champ de saisie
     */
    private String monChampDeSaisie;

    /**
     * Constructeur
     */
    public MonComposantsBean() {
        super();
    }

    /**
     * Accesseur pour l'attribut monChampDeSaisie
     * 
     * @return Retourne la valeur de l'attribut monChampDeSaisie.
     */
    public String getMonChampDeSaisie() {
        return this.monChampDeSaisie;
    }

    /**
     * Mutateur de l'attribut monChampDeSaisie
     * 
     * @param _monChampDeSaisie Valeur associée à l'attribut monChampDeSaisie.
     */
    public void setMonChampDeSaisie(String _monChampDeSaisie) {
        this.monChampDeSaisie = _monChampDeSaisie;
    }

}
