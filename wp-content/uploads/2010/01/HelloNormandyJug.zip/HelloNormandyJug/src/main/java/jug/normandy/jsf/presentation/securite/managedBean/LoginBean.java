package jug.normandy.jsf.presentation.securite.managedBean;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

/**
 * Classe de présentation relative à la connection à l'application
 * 
 * @author gTombette
 * @version $Revision$
 */
@ManagedBean(name="loginBean")
@RequestScoped
public class LoginBean implements Serializable {

    /**
     * Identifiant serialVersionUID pour la sérialisation
     */
    private static final long serialVersionUID = -6594123563658040565L;

    /**
     * Identifiant de l'utilisateur
     */
    private String identifiant;

    /**
     * Mot de passe de l'utilisateur
     */
    private String motDePasse;

    /**
     * Constructeur
     */
    public LoginBean() {
        super();
    }

    /**
     * Accesseur pour l'attribut identifiant
     * 
     * @return Retourne la valeur de l'attribut identifiant.
     */
    public String getIdentifiant() {
        return this.identifiant;
    }

    /**
     * Mutateur de l'attribut identifiant
     * 
     * @param _identifiant Valeur associée à l'attribut identifiant.
     */
    public void setIdentifiant(String _identifiant) {
        this.identifiant = _identifiant;
    }

    /**
     * Accesseur pour l'attribut motDePasse
     * 
     * @return Retourne la valeur de l'attribut motDePasse.
     */
    public String getMotDePasse() {
        return this.motDePasse;
    }

    /**
     * Mutateur de l'attribut motDePasse
     * 
     * @param _motDePasse Valeur associée à l'attribut motDePasse.
     */
    public void setMotDePasse(String _motDePasse) {
        this.motDePasse = _motDePasse;
    }

    /**
     * Méthode de soumission du formulaire de connexion à l'application
     * 
     * @return Chaîne de caractère pour préciser l'outcome de la méthode
     */
    public String soumettre() {
        String retour = "succes";

        // TODO : Appel du code métier

        return retour;
    }

}
