package jug.normandy.jsf.presentation.accueil.managedBean;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

/**
 * Classe de présentation relative à l'accueil à l'application
 * 
 * @author gTombette
 * @version $Revision$
 */
@ManagedBean(name="accueilBean")
@RequestScoped
public class AccueilBean implements Serializable {

    /**
     * Identifiant serialVersionUID pour la sérialisation
     */
     private static final long serialVersionUID = 2621049906731744746L;

     /**
     * Constructeur
     */
    public AccueilBean() {
        super();
    }


    /**
     * Méthode de de recherche de la page de composants à l'application
     * 
     * @return Chaîne de caractère pour préciser l'outcome de la méthode
     */
    public String recherche() {
        String retour = "composants";

        // TODO : Appel du code métier

        return retour;
    }

}
