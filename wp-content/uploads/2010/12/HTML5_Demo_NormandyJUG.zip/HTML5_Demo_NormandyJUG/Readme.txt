Les sources HTML/CSS/JS sont dans le r�pertoire du m�me nom.
Il suffit de copier le r�pertoire dans le root d'un serveur Web (www pour apache par exemple).

Pour simplifier l'authentification OAuth de Twitter, on a �crit une Servlet Java.
Les sources du projet Eclipse sont dans le r�pertoire Java\TweetReader.
Les sources du War saont dans Java\Twitter. Il suffit de d�poser TweetReader.jar (g�n�r� � partir du projet ci dessus) dans le r�pertoire WEB-INF\lib 
et de le zipper pour le d�ployer dans un tomcat par exemple.

Pour plus d'information sur l'authentificationTwitter voir http://dev.twitter.com/doc

1. Pour enregistrer votre d�mo comme application Twitter,  cr�er un profil avec l'url suivante : http://twitter.com/apps/new.
Dans le source TweetReader.java, remplacer le CONSUMER_KEY et le CONSUMER_SECRET par ceux que vous avez obtenus.

2. Pour obtenir la USER_KEY et le USER_SECRET pour l'authetification OAuth de Twitter, il faut ex�cuter le main de TweetReader 
une 1�re fois en d�commentant l'�tape 1 si elle est comment�e (showAuthentificationUrl();).
Suivre les instruction.
Dans le source TweetReader.java, commenter l'�tape 1 
et d�commenter l'�tape 2 
(showAccessCode("Remplacer par le RequestToken obtenu � l'�tape pr�c�dente", "Remplacer par le RequestSecret obtenu � l'�tape pr�c�dente", "Remplacer par le code Pin obtenu de Twitter");)
et remplacer les valeurs par celles obtenues (le code pin et les 2 .
Ex�cuter une 2�me fois le main de TweetReader.
Puis remplacer les valeurs USERN_USER_KEY et USERN_USER_SECRET par celles obtenues.

Recommencez le 2. autant de fois que vous avez d'utilisateur � suivre.

N'oubliez pas de mettre � jour vos utilisateurs dans le <select id="user"> du fichier index.html.
