var consoleWindows = window.open("http://localhost:90/demo_jug/debug.html", "Debug", "menubar=no,location=no,resizable=yes,scrollbars=yes,status=yes"); 
var usertimeline = null;
var db = null;
var tweetcounter = 0;
try {
    if (window.openDatabase) {
        db = openDatabase("Twitter", "1.0", "Twitter Feed", 200000);
    }
} catch(err) { }

var Twitter = {
    //Create table
    init : function(defaultuser) {
        trace('init');
        usertimeline = defaultuser;
        if (db) {
            //Have database? Read data
            db.transaction(function(tx) {
                tx.executeSql(
                    "CREATE TABLE IF NOT EXISTS status (id REAL UNIQUE, usertimeline TEXT, username TEXT, creationdate TEXT, text TEXT, avatar TEXT)", 
                    [], 
                    function(result) {
                        Twitter.readStatus();
                    }, 
                    function(tx, error) {
                        Twitter.readStatus();
                    }
                );
            });
        }
    },
    
    //Read statuses
    readStatus : function() {
        trace('read');
        db.transaction(function(tx) {
            tx.executeSql("SELECT id, usertimeline, username, creationdate, text, avatar FROM status where usertimeline = ? ORDER BY id DESC", [usertimeline], 
			function(tx, result) {
                trace("Some tweets found");
                var timeline = document.getElementById('timeline');
                timeline.innerHTML = '';
                
                for (var i = 0; i < result.rows.length; ++i) {
                    var row = result.rows.item(i);
                    Twitter.display(row);
                }
            }, function(tx, error) {
                trace("No tweets found");
                return;
            });
        });
    },
    
    //Display statuses
    display : function(row) {
        trace('display');
        var timeline = document.getElementById('timeline');
	
		var section = document.createElement('section');
		var d = new Date();
		d.setTime(Date.parse(row['creationdate']));
	
		section.innerHTML =
			'<img src="'+row['avatar']+'" alt="" height="24" widht="24"/>'+
            '<span class="user">'+row['username'] + '</span><p> ' +
            row['text'] +
            '</p> <time datetime="' + html5Date(d) + '" class="date">' + prettyDate(d) + '</time>';
			
		timeline.appendChild(section);
    },
    
    load : function(user, count) {
        trace('load');
		try {
			if (typeof(worker) != 'undefined') {
				trace('Terminate previous Worker');
				worker.terminate();
			}
			trace('Create new Worker with worker_twitter.js');
			worker = new Worker('worker_twitter.js');
			trace('Configure Worker');
			worker.onmessage = function(event) {
				trace('Worker recieved : ' + event.data);
				if (event.data == 'REFRESH_START') {
					tweetcounter = 0;
					document.getElementById('twitprogress').style.visibility = 'visible';
					document.getElementById("twitprogress").value = tweetcounter;
				} else if (event.data == 'REFRESHING') {
					tweetcounter++;
					document.getElementById("twitprogress").value = tweetcounter * 10;
				} else if (event.data == 'REFRESH_END') {
					document.getElementById('twitprogress').style.visibility = 'hidden';
				} else if (typeof(event.data) == "string" && event.data.substring(0, 5) == 'ERROR') {
					document.getElementById('twitfooter').innerHTML = 'Error loading tweets';
					trace(event.data);
				} else if (typeof(event.data) == "string" && event.data.substring(0, 7) == 'CONSOLE') {
					trace(event.data.substring(7));
				} else {
					Twitter.twitterCallback(event.data);
				}
			};
			worker.onerror = function(event) {
				trace("ERROR => " + event.data);
			};
			trace('Start Worker with user = ' + user + ' and count = ' + count);
			usertimeline = user;
			worker.postMessage({'user' : user, 'count' : count});
		} catch(err) { 
				trace('Error : ' + err);
		}
    },
    
    twitterCallback : function(obj) {
        trace('callback');
        
        if (db) {
            var inserts = [];
			var status = [
				obj.id,
				obj.usertimeline,
				obj.username,
				obj.text,
				obj.creationdate,
				obj.avatar
			]
			inserts.push(status);
            Twitter.insert(inserts, Twitter.readStatus);
        } else {
            //No database? just display
			Twitter.display({
				'id' : obj.id,
				'usertimeline' : obj.usertimeline, 
				'username' : obj.username,
				'text' : obj.text,
				'creationdate' : obj.creationdate,
				'avatar' : obj.avatar
			});
        }
    },
    
    //Synchronous insert
    insert : function(arStatus, callback) {
        trace('insert');
        var status = arStatus.pop();
		trace(status);
        var sql = "INSERT INTO status (id, usertimeline, username, text, creationdate, avatar) VALUES (?,?,?,?,?,?)";
        
        db.transaction(
            function (tx) {
                tx.executeSql(
                    sql,
                    status,
                    function(tx, result){
						trace('insert OK');
                        if (arStatus.length > 0) {
                            Twitter.insert(arStatus, callback);
                        } else {
                            callback();
                        }
                    },
                    function(tx, error){
						trace('insert KO');
                        if (arStatus.length > 0) {
                            Twitter.insert(arStatus, callback);
                        } else {
                            callback();
                        }
                    }
                );
            }
        );
    }
}

function trace(info) {
	if (console != 'undefined') {
		console.log(info);
	console.log(consoleWindows == null || consoleWindows == 'undefined');
	}
	if (consoleWindows != 'undefined') {
		consoleWindows.postMessage(info, "*");
	}
}

function html5Date(datetime) {
    var date = new Date(datetime);
	return date.getUTCFullYear() + "-" + date.getUTCMonth() + "-" + date.getUTCDay() + "T" + date.getUTCHours() + ":" + date.getUTCMinutes() + "Z";
}

function prettyDate(time){
    var date = new Date();
    date.setTime(time); // milliseconds
    var diff = (((new Date()).getTime() - date.getTime()) / 1000);
    var day_diff = Math.floor(diff / 86400);
    if ( isNaN(day_diff) || day_diff < 0 || day_diff >= 31 )
        return date.toLocaleString();
            
    return day_diff == 0 && (
            diff < 60 && "just now" ||
            diff < 120 && "1 minute ago" ||
            diff < 3600 && Math.floor( diff / 60 ) + " minutes ago" ||
            diff < 7200 && "1 hour ago" ||
            diff < 86400 && Math.floor( diff / 3600 ) + " hours ago") ||
        day_diff == 1 && "Yesterday" ||
        day_diff < 7 && day_diff + " days ago" ||
        day_diff < 31 && Math.ceil( day_diff / 7 ) + " weeks ago";
}