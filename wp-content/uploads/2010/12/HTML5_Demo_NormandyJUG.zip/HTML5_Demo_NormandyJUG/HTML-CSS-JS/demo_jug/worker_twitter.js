var url = '';
var userid = '';

var Twitter = {

    //Display statuses
    send : function(row) {
		postMessage(row);
    },
 	refresh : function() {
		var xhr = new XMLHttpRequest();  
		xhr.open('GET', url, true);
		xhr.onreadystatechange = function (aEvt) {  
			if (xhr.readyState == 4) {  
				if(xhr.status == 200) {
					Twitter.twitterCallback(eval(xhr.responseText));
					Twitter.send("REFRESH_END");
					setTimeout("Twitter.refresh()", 15000);
				} else {
					Twitter.send("ERROR => Error HTTP " + xhr.status + " : " + xhr.statusText);
				}				
			}  
		};
		Twitter.send("REFRESH_START");
		xhr.send();  		
    },
    
    twitterCallback : function(obj) {
		for (var i=0, l=obj.length; i<l; i++) {
			Twitter.send("REFRESHING");
			var status = {'id' : obj[i].id, 'usertimeline' : userid, 'username' : obj[i].user.screen_name, 'text' : obj[i].text, "creationdate" : obj[i].created_at, 'avatar' : obj[i].user.profile_image_url};
			Twitter.send(status);
		}
    }
}

onmessage = function(event) {
	userid = event.data.user;
	var count = event.data.count;
	url = 'http://localhost:8081/twitter/TweetReader?user=' + userid + "&count=" + count;

	try {
		Twitter.refresh();
	} catch(err) {
		throw err;
	}

};