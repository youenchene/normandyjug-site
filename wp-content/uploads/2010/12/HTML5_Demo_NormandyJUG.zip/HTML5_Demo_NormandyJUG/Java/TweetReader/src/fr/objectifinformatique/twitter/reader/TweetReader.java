package fr.objectifinformatique.twitter.reader;


import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Date;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.http.AccessToken;
import twitter4j.http.RequestToken;

import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;

public class TweetReader extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7674446405700466085L;
	
	private static final String USER1 = "Mettre votre username Twitter"
	private static final String USER2 = "Mettre votre username Twitter"
	private static final String USER3 = "Mettre votre username Twitter"
	
	private static final String CONSUMER_KEY = "Sv6WeRNu7p8iex9ddBVuQ";
	private static final String CONSUMER_SECRET = "3sC5tovE8IVSceSq36ztV1SOfEGAp9UVAcgmm4ya8Q";
	
	private static final String USER1_USER_KEY = "Remplacer par la user key obtenue";
	private static final String USER1_SECRET = "Remplacer par le secret obtenu";
	
	private static final String USER2_USER_KEY = "Remplacer par la user key obtenue";
	private static final String USER2_SECRET = "Remplacer par le secret obtenu";
	
	private static final String USER3_USER_KEY = "Remplacer par la user key obtenue";
	private static final String USER3_SECRET = "Remplacer par le secret obtenu";
	
	
	
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String userKey = null;
		String userSecret = null;
		int count = -1;
		
		if (req.getParameter("user") != null) {
			if (req.getParameter("user").equals(USER1)) {
				userKey = USER1_USER_KEY;
				userSecret = USER1_SECRET;
			} else if (req.getParameter("user").equals(USER2)) {
				userKey = USER2_USER_KEY;
				userSecret = USER2_SECRET;
			} else if (req.getParameter("user").equals(USER3)) {
				userKey = USER3_USER_KEY;
				userSecret = USER3_SECRET;				
			}			
		} else {
			return;
		}
		
		if (req.getParameter("count") != null) {
			count = Integer.parseInt(req.getParameter("count"));
		}
		
		try {
			String urlString = this.getJsonAccess(userKey, userSecret, count);
			
			// On prend en input le fichier r�cup�r� sur twitter
			URL url = new URL(urlString);
			URLConnection urlConnection = url.openConnection();
			InputStream in = urlConnection.getInputStream();

			// Et on output sur le stream de la servlet
			OutputStream out = resp.getOutputStream();
			resp.setContentType("application/octet-stream");
			resp.setHeader("Content-Disposition","attachment;filename=home_timeline.json");
			resp.setHeader("Access-Control-Allow-Origin","*");
			
			byte[] buffer = new byte[4096];
            int bytes_read;
            while((bytes_read = in.read(buffer)) != -1) {
                out.write(buffer, 0, bytes_read);
			}
		} catch (Exception e) {
			System.err.println("Erreur " + e.getClass() + " " + e.getMessage());
		}
 
	}
	
	private String getJsonAccess (String userKey, String userSecret, int count) throws UnsupportedEncodingException, NoSuchAlgorithmException, InvalidKeyException {
		/* initialisation des variables */
		String method = "GET";
		
		String url = "http://api.twitter.com/1/statuses/home_timeline.json";

		String oauth_consumer_key = CONSUMER_KEY;
		String oauth_token = userKey;
	
		/* Ces deux code ne sont pas cens�s apparaitre en clair dans le code, ici c'est juste pour tester */
		String oauth_consumer_secret = CONSUMER_SECRET;
		String oauth_token_secret = userSecret;
	
		/* code g�n�r� al�atoirement */
		String oauth_nonce = "i4ds5efs68bzeb4e6zeqsdf";
		/* On g�n�re un timestamp, la requ�te d'obtention du fichier n'est valique que quelques minutes */
		String oauth_timestamp = new Integer((int)(new Date().getTime()/1000)).toString();
		
		
		String completeParameter = "oauth_consumer_key=" + oauth_consumer_key + "&oauth_nonce=" + oauth_nonce + "&oauth_signature_method=HMAC-SHA1&oauth_timestamp=" + oauth_timestamp + "&oauth_token=" + oauth_token + "&oauth_version=1.0";
		String textToSign = method + "&" + URLEncoder.encode(url, "ISO-8859-1") + "&" + (count!=-1?URLEncoder.encode("count=" + count + "&", "ISO-8859-1"):"") + URLEncoder.encode(completeParameter, "ISO-8859-1");

		/* la cl� de signature est la concat�nation de la cl� secrete application et la cl� secrete de l'utilisateur */
		String keyForSign = URLEncoder.encode(oauth_consumer_secret, "ISO-8859-1") + "&" + URLEncoder.encode(oauth_token_secret, "ISO-8859-1");
		
		// Cr�ation de la cl� de cryptage
		SecretKeySpec signingKey = new SecretKeySpec(keyForSign.getBytes(), "HmacSHA1");

		// Cr�ation de l'encodeur HMAC, et initialisation de la cl�
		Mac mac = Mac.getInstance("HmacSHA1");
		mac.init(signingKey);
 
		// Passage a la moulinette de l'url pour obtenir la signature
		String signature = Base64.encode(mac.doFinal(textToSign.getBytes()));
		
		// Construction de l'url finale, avec la signature encod�e int�gr�e
		String finalUrl = url + "?" + (count!=-1?"count=" + count + "&":"") + completeParameter + "&oauth_signature=" + URLEncoder.encode(signature, "ISO-8859-1");
		
		System.out.println("MAC : " + signature);
		System.out.println("URL : " + finalUrl);
			
		return finalUrl;
	}
	
	public TweetReader() {}
	
	public static void main(String[] args) {
		new TweetReader();

		try {
			//Etape  1
			showAuthentificationUrl();
			//Etape 2
			//showAccessCode("Remplacer par le RequestToken obtenu � l'�tape pr�c�dente", "Remplacer par le RequestSecret obtenu � l'�tape pr�c�dente", "Remplacer par le code Pin obtenu de Twitter");
		} catch (TwitterException e) {
			e.printStackTrace();
		}
	}
	
	public static void showAuthentificationUrl () throws TwitterException {
		System.out.println("Etape 1");
		Twitter twitter = new TwitterFactory().getInstance();
		twitter.setOAuthConsumer(CONSUMER_KEY, CONSUMER_SECRET);
		
		RequestToken requestToken = twitter.getOAuthRequestToken();
		
		//Affiche le token de demande d'authentification, necessaire afin d'obtenir le code d'acces utilisateur
		System.out.println("Valeurs � recopier dans l'�tape 2"
		System.out.println("Request Token = " + requestToken.getToken());
		System.out.println("Request Token Secret = " + requestToken.getTokenSecret());
		
		//Affiche l'URL d'authentification, � copier dans le navigateur pour obtenir le pin du compte logu�
		System.out.println("Copier cette URL dans un navigateur : " + requestToken.getAuthorizationURL());
		System.out.println("Signez vous dans Twitter si n�cessaire et copier le code Pin dans l'�tape 2");
	}
	
	public static void showAccessCode (String requestToken, String requestSecret, String pin) throws TwitterException {
		System.out.println("Etape 2");
		Twitter twitter = new TwitterFactory().getInstance();
		twitter.setOAuthConsumer(CONSUMER_KEY, CONSUMER_SECRET);
		
		//R�cup�re le token d'acc�s utilisateur a partir du token de requete pr�c�dent et du pin
		AccessToken accessToken = twitter.getOAuthAccessToken(new RequestToken(requestToken, requestSecret), pin);
		
		//Affiche le tout
		System.out.println("Valeurs � recopier dans les constantes USERn_USER_KEY et USERn_USER_SECRET");
		System.out.println("USER_KEY = " + accessToken.getToken());
		System.out.println("USER_SECRET = " + accessToken.getTokenSecret());
	}
	
}
