package fr.objectifinformatique.twitter.reader;


import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;

public class NewsReader extends HttpServlet {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8466272127396212484L;


	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		try {
			String urlString = req.getParameter("url");
			int pos = urlString.substring(9).indexOf("/") + 10;
			String domaine = urlString.substring(0, pos);
			URL url = new URL(urlString);
			URLConnection urlConnection = url.openConnection();
			InputStream in = urlConnection.getInputStream();
			String news = IOUtils.toString(in, "UTF-8");

			news = news.replaceAll("é", "&#233;").replaceAll("ê", "&#234;")
						.replaceAll("è", "&#232;").replaceAll("ô", "&#244;")
						.replaceAll("ç", "&#231;").replaceAll("û", "&#249;")
						.replaceAll("�.", "&#224;").replaceAll("src=\"/", "src=\"" + domaine);
			
			// Et on output sur le stream de la servlet
			OutputStream out = resp.getOutputStream();
			resp.setContentType("application/xml");
//			resp.setHeader("Content-Disposition","attachment;filename=rss.xml");
			resp.setHeader("Access-Control-Allow-Origin","*");
			
			IOUtils.write(news, out, "UTF-8");
			out.flush();
            
		} catch (Exception e) {
			System.err.println("Erreur " + e.getClass() + " " + e.getMessage());
		}
 
	}
		
}
